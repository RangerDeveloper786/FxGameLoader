<?php 

echo "helli;

?>