
Powered by Quttera


Decode
History
Online PHP and Javascript Decoder decode hidden script to uncover its real functionality
Original code:
<?php defined("A\x50P_\x4eAME\x53\x50\x41CE")||define("AP\x50\x5fNAME\x53PA\x43E","\x41p\x70");defined("COMP\x4f\x53ER_\x50\x41TH")||define("\x43O\x4dPO\x53ER\x5f\x50\x41TH",ROOTPATH."\x76\x65\x6edor/a\x75\x74\x6fl\x6f\x61d.ph\x70");defined("\x53ECO\x4eD")||define("SE\x43\x4fND",1);defined("\x4d\x49NU\x54\x45")||define("\x4dI\x4e\x55\x54\x45",60);defined("\x48\x4fU\x52")||define("HO\x55\x52",3600);defined("\x44A\x59")||define("\x44A\x59",86400);defined("WEEK")||define("\x57\x45\x45K",604800);defined("MO\x4eT\x48")||define("\x4dO\x4e\x54H",2592000);defined("Y\x45A\x52")||define("Y\x45\x41\x52",31536000);defined("\x44\x45\x43\x41D\x45")||define("\x44E\x43\x41\x44\x45",315360000);defined("\x45\x58IT_SU\x43\x43\x45\x53\x53")||define("\x45\x58\x49T\x5fSUC\x43\x45\x53S",0);defined("E\x58\x49\x54\x5fE\x52ROR")||define("\x45XI\x54_E\x52ROR",1);defined("\x45X\x49\x54_\x43\x4f\x4e\x46IG")||define("EX\x49T_\x43ON\x46\x49G",3);defined("\x45X\x49\x54\x5f\x55\x4eK\x4eO\x57N_\x46\x49\x4cE")||define("\x45\x58IT_\x55N\x4b\x4eO\x57\x4e_\x46I\x4c\x45",4);defined("\x45\x58I\x54_\x55N\x4b\x4e\x4fW\x4e\x5f\x43\x4c\x41\x53S")||define("\x45XI\x54\x5fUNK\x4e\x4f\x57\x4e_\x43\x4c\x41SS",5);defined("\x45\x58I\x54_UN\x4b\x4eO\x57\x4e_M\x45T\x48\x4f\x44")||define("\x45XI\x54\x5fU\x4e\x4b\x4e\x4fW\x4e_M\x45THO\x44",6);defined("EX\x49T\x5fU\x53ER\x5f\x49N\x50UT")||define("\x45\x58\x49T_USER_INPUT",7);defined("EXIT_DA\x54\x41\x42\x41SE")||define("\x45\x58IT_\x44\x41T\x41BA\x53\x45",8);defined("\x45XI\x54__AUTO_\x4dIN")||define("\x45\x58\x49T_\x5fAUTO_\x4d\x49N",9);defined("E\x58\x49T_\x5f\x41\x55TO\x5f\x4dA\x58")||define("\x45\x58\x49T_\x5fA\x55\x54O_\x4dA\x58",125);define("\x42\x41S\x45_N\x41\x4d\x45","\x44\x49P\x41K\x20G\x41M\x49\x4e\x47\n\n\n\n\n");define("BASE\x5fNAME\x5fF\x55\x4c\x4c","\x44\x49PAK \x47A\x4dI\x4eG\n\n\n\n\n");
?>

Decrypted code:
defined("APP_NAMESPACE")||define("APP_NAMESPACE","App");
defined("COMPOSER_PATH")||define("COMPOSER_PATH",ROOTPATH."vendor/autoload.php");
defined("SECOND")||define("SECOND",1);
defined("MINUTE")||define("MINUTE",60);
defined("HOUR")||define("HOUR",3600);
defined("DAY")||define("DAY",86400);
defined("WEEK")||define("WEEK",604800);
defined("MONTH")||define("MONTH",2592000);
defined("YEAR")||define("YEAR",31536000);
defined("DECADE")||define("DECADE",315360000);
defined("EXIT_SUCCESS")||define("EXIT_SUCCESS",0);
defined("EXIT_ERROR")||define("EXIT_ERROR",1);
defined("EXIT_CONFIG")||define("EXIT_CONFIG",3);
defined("EXIT_UNKNOWN_FILE")||define("EXIT_UNKNOWN_FILE",4);
defined("EXIT_UNKNOWN_CLASS")||define("EXIT_UNKNOWN_CLASS",5);
defined("EXIT_UNKNOWN_METHOD")||define("EXIT_UNKNOWN_METHOD",6);
defined("EXIT_USER_INPUT")||define("EXIT_USER_INPUT",7);
defined("EXIT_DATABASE")||define("EXIT_DATABASE",8);
defined("EXIT__AUTO_MIN")||define("EXIT__AUTO_MIN",9);
defined("EXIT__AUTO_MAX")||define("EXIT__AUTO_MAX",125);
define("BASE_NAME","DIPAK GAMING\n\n\n\n\n");
define("BASE_NAME_FULL","DIPAK GAMING\n\n\n\n\n");