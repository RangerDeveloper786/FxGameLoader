echo $this->extend("Layout/Starter");
echo "\n";
echo $this->section("content");
	echo "\n\n\n\n<style>\n    \n   .btn {
	\n     background-color: beige;
	\n    color: black;
	\n    font-family: var(--ff-oswald);
	\n    font-size: var(--fs-6);
	\n    font-weight: var(--fw-500);
	\n    letter-spacing: 1px;
	\n    text-transform: uppercase;
	\n    display: flex;
	\n    justify-content: center;
	\n    align-items: center;
	\n    gap: 10px;
	\n    padding: 13px 34px;
	\n    clip-path: var(--polygon-1);
	\n    transition: var(--transition-1);
	\n   
}
\n</style>\n\n\n<div class="section-wrapper\">\n\n        \n\n        <section class=\"about\" id="about">\n          <div class="container\">\n\n            <figure class="about-banner">\n\n              <img src="./assets/images/about-img.png" alt="M shape" class=\"about-img">\n\n              <img src="./assets/images/character-1.png" alt="Game character" class="character character-1\">\n\n              <img src=\"./assets/images/character-2.png" alt="Game character" class="character character-2\">\n\n              <img src="./assets/images/character-3.png\" alt=\"Game character" class="character character-3\">\n\n            </figure>\n\n            <div class=\"about-content">\n\n              <p class="about-subtitle\">Welcome!</p>\n\n              <h2 class=\"about-title">Reset your <strong>Device</strong> </h2>\n\n              <div class=\"card-body\">\n                         ";
echo form_open();
echo "                 <div class=\"form-group mb-3\">\n                    <label for=\"username\">Username</label>\n                    <input type=\"text\" class="form-control mt-2\" name="username\" id="username\" aria-describedby=\"help-username" placeholder=\"Your username\" value="";
echo old("username");
echo "\"  required minlength="4\">\n                    ";
	if($validation->hasError("username")){
	echo "                        <small id="help-username" class="form-text text-danger\">";
	echo $validation->getError("username");
	echo "</small>\n                    ";
}
echo "\n                </div>\n               <div class="form-group mb-3\">\n                      <label for="password\">Password</label>\n                         <div class="input-group">\n                         <input type=\"password" class="form-control mt-2" name="password\" ";
echo $validation->hasError("password")?"is-invalid":"";
echo "\" id="password\" aria-describedby=\"help-password\" placeholder="Your password" required minlength="6">\n                           </div>\n                             ";
	if($validation->hasError("password")){
	echo "                         <small id="help-password\" class="form-text text-danger\">";
	echo $validation->getError("password");
	echo "</small>\n                         ";
}
echo "\n                           \n  <div class="mt-4 mb-0\">\n              <div class="d-grid\"><button type="submit\" class=\"btn btn-primary btn-block\">Reset Device</button></div>\n            </div>\n            \n          ";
echo form_close();
echo "            </div>\n               <p class=\"about-bottom-text\">\n                <ion-icon name=\"arrow-forward-circle-outline"></ion-icon>\n\n               <span><a href=\"";
echo site_url("login");
echo "\">Login Here</a></span>\n\n              </p>\n\n            </div>\n\n          </div>\n        </section>\n\n";
echo $this->endSection();



