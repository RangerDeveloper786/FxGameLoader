echo $this->extend("Layout/Starter");
echo "\n";
echo $this->section("content");
	echo "\n\n\n<style>\n    \n   .btn {
	\n     background-color: beige;
	\n    color: black;
	\n    font-family: var(--ff-oswald);
	\n    font-size: var(--fs-6);
	\n    font-weight: var(--fw-500);
	\n    letter-spacing: 1px;
	\n    text-transform: uppercase;
	\n    display: flex;
	\n    justify-content: center;
	\n    align-items: center;
	\n    gap: 10px;
	\n    padding: 13px 34px;
	\n    clip-path: var(--polygon-1);
	\n    transition: var(--transition-1);
	\n   
}
\n</style>\n\n\n\n<div class=\"section-wrapper\">\n\n        \n\n        <section class="about" id="about\">\n          <div class="container">\n\n            <figure class=\"about-banner">\n\n              <img src=\"./assets/images/about-img.png" alt=\"M shape" class="about-img">\n\n              <img src="./assets/images/character-1.png\" alt=\"Game character" class="character character-1\">\n\n              <img src="./assets/images/character-2.png" alt="Game character\" class="character character-2\">\n\n              <img src="./assets/images/character-3.png" alt=\"Game character\" class="character character-3\">\n\n            </figure>\n\n            <div class=\"about-content">\n\n              <p class="about-subtitle">Welcome!</p>\n\n              <h2 class=\"about-title">Register to <strong>Panel</strong> </h2>\n\n            <div class=\"card-body\">\n                ";
echo form_open();
echo "                <div class=\"form-group mb-3">\n        <label for=\"fullname">Full Name</label>\n        <input type=\"text" class=\"form-control mt-2\" name="fullname\" id="fullname\" aria-describedby=\"help-fullname\" placeholder="Your full name\" minlength="3\" maxlength=\"255" value="";
echo old("fullname");
echo "" required>\n        ";
	if($validation->hasError("fullname")){
	echo "            <small id="help-fullname\" class=\"form-text text-danger\">";
	echo $validation->getError("fullname");
	echo "</small>\n        ";
}
echo "\n    </div>\n                <div class=\"form-group mb-3">\n                    <label for="username\">Username</label>\n                    <input type=\"text" class=\"form-control mt-2" name="username\" id="username" aria-describedby="help-username" placeholder=\"Your username\" minlength=\"4" maxlength=\"24\" value="";
echo old("username");
echo "" required>\n                    ";
	if($validation->hasError("username")){
	echo "                        <small id="help-username\" class=\"form-text text-danger">";
	echo $validation->getError("username");
	echo "</small>\n                    ";
}
echo "\n                </div>\n                <div class="form-group mb-3">\n                    <label for=\"password\">Password</label>\n                    <input type=\"password\" class="form-control mt-2\" name="password" id=\"password" aria-describedby="help-password" placeholder=\"Your password" minlength="6" maxlength=\"24" required>\n                    ";
	if($validation->hasError("password")){
	echo "                        <small id="help-password" class=\"form-text text-danger">";
	echo $validation->getError("password");
	echo "</small>\n                    ";
}
echo "\n                </div>\n                <div class=\"form-group mb-3\">\n                    <label for=\"password2">Confirm Password</label>\n                    <input type=\"password\" name="password2\" id="password2\" class=\"form-control mt-2" placeholder=\"Confirm password" aria-describedby=\"help-password2\" minlength=\"6" maxlength=\"24" required>\n                    ";
	if($validation->hasError("password2")){
	echo "                        <small id=\"help-password2\" class=\"form-text text-danger\">";
	echo $validation->getError("password2");
	echo "</small>\n                    ";
}
echo "\n                </div>\n                <div class="form-group mb-3\">\n                    <label for="referral\">Referral Code</label>\n                    <input type="text" name=\"referral\" id=\"referral\" class="form-control mt-2\" placeholder=\"Referral code\" aria-describedby=\"help-referral" value=\"";
echo old("referral");
echo "" maxlength="25\" required>\n                    ";
	if($validation->hasError("referral")){
	echo "                        <small id=\"help-referral\" class=\"form-text text-danger">";
	echo $validation->getError("referral");
	echo "</small>\n                    ";
}
echo "\n                </div>\n              \n                \n                \n                <div class="form-group mb-2">\n                    <button type=\"submit" class="btn btn-outline-secondary\"><i class="bi bi-box-arrow-in-right\"></i> Register</button>\n                </div>\n                ";
echo form_close();
echo "\n            </div>\n        </div>\n       \n    </div>\n\n";
echo $this->endSection();
echo "\n\n";



