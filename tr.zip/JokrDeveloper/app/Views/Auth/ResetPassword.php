	${
	"GLOBALS"
}
["fbivlvue"]="new_password";
	${
	"GLOBALS"
}
["cdivlcsn"]="success";
	${
	"GLOBALS"
}
["gycpedjjeyp"]="msgDanger";
echo $this->extend("Layout/Starter");
echo "\n";
echo $this->section("content");
	echo "\n<style>\n    \n   .btn {
	\n     background-color: beige;
	\n    color: black;
	\n    font-family: var(--ff-oswald);
	\n    font-size: var(--fs-6);
	\n    font-weight: var(--fw-500);
	\n    letter-spacing: 1px;
	\n    text-transform: uppercase;
	\n    display: flex;
	\n    justify-content: center;
	\n    align-items: center;
	\n    gap: 10px;
	\n    padding: 13px 34px;
	\n    clip-path: var(--polygon-1);
	\n    transition: var(--transition-1);
	\n   
}
\n</style>\n\n<div class="section-wrapper\">\n\n        \n ";
	if(isset(${
		${
		"GLOBALS"
	}
	["gycpedjjeyp"]
}
	)){
	echo "            <div class=\"alert alert-danger\">";
		echo ${
			${
			"GLOBALS"
		}
		["gycpedjjeyp"]
	};
	echo "</div>\n        ";
}
echo "\n\n        ";
	if(isset(${
		${
		"GLOBALS"
	}
	["cdivlcsn"]
}
	)){
	$xqylrmw="success";
	echo "            <div class="alert alert-success">";
		echo ${
		$xqylrmw
	};
	echo "</div>\n        ";
}
echo "\n        <section class=\"about" id="about\">\n          <div class="container\">\n\n            <figure class=\"about-banner">\n\n              <img src=\"./assets/images/about-img.png" alt=\"M shape" class="about-img">\n\n              <img src=\"./assets/images/character-1.png" alt=\"Game character\" class="character character-1">\n\n              <img src="./assets/images/character-2.png" alt=\"Game character" class="character character-2\">\n\n              <img src=\"./assets/images/character-3.png" alt="Game character\" class=\"character character-3\">\n\n            </figure>\n\n            <div class="about-content">\n\n              <p class=\"about-subtitle\">Welcome</p>\n\n              <h2 class=\"about-title">Rest your  <strong>Password</strong> </h2>\n\n               <div class="card-body">\n                 <form action="";
echo base_url("resetPassword");
echo "\" method="post" enctype=\"multipart/form-data\">\n        ";
echo csrf_field();
echo "            <div class=\"form-group">\n                <label for="username\">Username</label>\n                <input type=\"text\" name="username\" id=\"username\" class="form-control";
echo ($validation->hasError("username"))?" is-invalid":"";
echo "" value=\"";
echo old("username");
echo "\">\n                ";
	if($validation->hasError("username")){
	echo "                    <div class=\"invalid-feedback\">";
	echo $validation->getError("username");
	echo "</div>\n                ";
}
echo "\n            </div>\n          <div class="form-group">\n            <label for=\"old_password">Old Password</label>\n            <input type=\"password\" name=\"old_password\" id=\"old_password" class=\"form-control";
echo ($validation->hasError("old_password"))?" is-invalid":"";
echo "\">\n            ";
	if($validation->hasError("old_password")){
	echo "                <div class=\"invalid-feedback\">";
	echo $validation->getError("old_password");
	echo "</div>\n            ";
}
echo "\n        </div>\n            <div class="form-group\">\n                <label for="new_password\">New Password</label>\n                <input type="password\" name=\"new_password" id=\"new_password\" class=\"form-control";
echo ($validation->hasError("new_password"))?" is-invalid":"";
echo "">\n                ";
	if($validation->hasError("new_password")){
	echo "                    <div class=\"invalid-feedback\">";
	echo $validation->getError("new_password");
	echo "</div>\n                ";
}
echo "\n            </div>\n\n            <div class=\"form-group\">\n                <label for=\"confirm_password\">Confirm New Password</label>\n                <input type=\"password\" name="confirm_password\" id=\"confirm_password" class=\"form-control";
echo ($validation->hasError("confirm_password"))?" is-invalid":"";
echo "">\n                ";
	if($validation->hasError("confirm_password")){
	echo "                    <div class=\"invalid-feedback\">";
	echo $validation->getError("confirm_password");
	echo "</div>\n                ";
}
echo "\n            </div>\n<br>\n            <button type=\"submit" class="btn btn-dark">Reset Password</button>\n        </form>\n            </div>\n   <p class="mt-4 text-sm text-center\">\nDon't have an account?\n<a href="";
echo site_url("login");
echo "\" class=\"text-primary text-gradient font-weight-bold">Login</a>\n</p>\n              <p class="about-bottom-text">\n                <ion-icon name="arrow-forward-circle-outline\"></ion-icon>\n\n                <span>Will sharpen your brain and focus</span>\n              </p>\n\n            </div>\n\n          </div>\n        </section>\n\n\n<script src=\"https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.all.min.js"></script>\n<script>\n    // Check if the SweetAlert notification needs to be shown\n    ";
	if(session()->getFlashdata("show_sweet_alert")){
		echo "        // Display SweetAlert notification\n        Swal.fire({
		\n            title: 'Password Reset Successful',\n            html: 'Your new password is: <strong>";
			echo ${
				${
				"GLOBALS"
			}
			["fbivlvue"]
		};
		echo "</strong><br><br><button class=\"btn btn-primary\" id=\"copyPasswordBtn">Copy Password</button>',\n            icon: 'success',\n            confirmButtonColor: '#3085d6',\n            confirmButtonText: 'OK',\n            allowOutsideClick: false,\n            showCloseButton: true,\n            footer: 'This dialog will close automatically in 5 seconds.',\n            timer: 5000,\n            timerProgressBar: true,\n        
	}
		).then((result) => {
			\n            if (result.isConfirmed) {
			\n                // SweetAlert confirmation button clicked\n                // You can add any desired action here\n            
		}
		\n        
	}
	);
		\n\n        // Function to copy the password to clipboard\n        document.getElementById("copyPasswordBtn\").addEventListener(\"click", function() {
		\n            copyToClipboard(\"";
			echo ${
				${
				"GLOBALS"
			}
			["fbivlvue"]
		};
		echo "\");
			\n            Swal.fire({
			\n                icon: 'success',\n                title: 'Password Copied!',\n                showConfirmButton: false,\n                timer: 1500,\n                timerProgressBar: true,\n            
		}
		);
		\n        
	}
	);
		\n\n        // Function to copy text to clipboard\n        function copyToClipboard(text) {
		\n            const textarea = document.createElement("textarea\");
		\n            textarea.value = text;
		\n            textarea.style.position = \"fixed\";
		\n            document.body.appendChild(textarea);
		\n            textarea.select();
		\n            document.execCommand(\"copy\");
		\n            document.body.removeChild(textarea);
		\n        
	}
	\n    ";
}
echo "\n</script>\n";
echo $this->endSection();


