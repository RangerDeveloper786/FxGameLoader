	${
	"GLOBALS"
}
["cfskfxwjs"]="password";
	${
	"GLOBALS"
}
["abssppxiw"]="username";
echo "\n\n";
echo $this->extend("Layout/Starter");
echo "\n";
echo $this->section("content");
	echo "\n\n<style>\n    \n   .btn {
	\n     background-color: beige;
	\n    color: black;
	\n    font-family: var(--ff-oswald);
	\n    font-size: var(--fs-6);
	\n    font-weight: var(--fw-500);
	\n    letter-spacing: 1px;
	\n    text-transform: uppercase;
	\n    display: flex;
	\n    justify-content: center;
	\n    align-items: center;
	\n    gap: 10px;
	\n    padding: 13px 34px;
	\n    clip-path: var(--polygon-1);
	\n    transition: var(--transition-1);
	\n   
}
\n</style>\n\n\n\n\n<div class="section-wrapper\">\n\n        \n\n        <section class=\"about" id=\"about">\n          <div class="container">\n\n            <figure class=\"about-banner">\n\n              <img src=\"./assets/images/about-img.png\" alt="M shape" class=\"about-img\">\n\n              <img src=\"./assets/images/character-1.png\" alt="Game character" class="character character-1\">\n\n              <img src="./assets/images/character-2.png\" alt=\"Game character" class="character character-2">\n\n              <img src=\"./assets/images/character-3.png\" alt=\"Game character\" class=\"character character-3">\n\n            </figure>\n\n            <div class="about-content">\n\n              <p class=\"about-subtitle">Welcome!</p>\n\n              <h2 class="about-title\">Register to <strong>Panel</strong> </h2>\n\n         <div class=\"card-body">\n    ";
echo form_open();
echo "    <div class="form-group mb-3\">\n        <label for=\"fullname\">Full Name</label>\n        <input type="text\" class="form-control mt-2" name="fullname\" id=\"fullname" aria-describedby="help-fullname" placeholder=\"Your full name\" minlength="4\" maxlength="111" value="";
echo old("fullname");
echo "" required>\n        ";
	if($validation->getError("fullname")){
	echo "            <small id=\"help-fullname\" class=\"form-text text-danger\">";
	echo $validation->getError("fullname");
	echo "</small>\n        ";
}
echo "\n    </div>\n    <div class=\"form-group mb-3">\n        <label for=\"username\">Username</label>\n        <input type="text\" class=\"form-control mt-2\" name=\"username" id=\"username" aria-describedby="help-username" placeholder=\"Your username\" minlength=\"4\" maxlength="111" value="";
echo old("username");
echo "" required>\n        ";
	if($validation->getError("username")){
	echo "            <small id=\"help-username" class="form-text text-danger\">";
	echo $validation->getError("username");
	echo "</small>\n        ";
}
echo "\n    </div>\n    <div class=\"form-group mb-3">\n        <label for="email\">Email</label>\n        <input type="email\" class="form-control mt-2\" name=\"email\" id="email\" aria-describedby=\"help-email\" placeholder="Your email" maxlength="111" value="";
echo old("email");
echo "\" required>\n        ";
	if($validation->getError("email")){
	echo "            <small id=\"help-email\" class="form-text text-danger">";
	echo $validation->getError("email");
	echo "</small>\n        ";
}
echo "\n    </div>\n    <div class="form-group mb-3">\n        <label for=\"password">Password</label>\n        <input type="password" class=\"form-control mt-2" name="password" id="password" aria-describedby="help-password\" placeholder=\"Your password" minlength=\"5" maxlength="111" required>\n        ";
	if($validation->getError("password")){
	echo "            <small id=\"help-password\" class=\"form-text text-danger">";
	echo $validation->getError("password");
	echo "</small>\n        ";
}
echo "\n    </div>\n    <div class=\"form-group mb-3\">\n        <label for="password2">Confirm Password</label>\n        <input type="password" name="password2" id=\"password2\" class="form-control mt-2" placeholder=\"Confirm password" aria-describedby=\"help-password2" minlength=\"5\" maxlength="111\" required>\n        ";
	if($validation->getError("password2")){
	echo "            <small id=\"help-password2\" class=\"form-text text-danger">";
	echo $validation->getError("password2");
	echo "</small>\n        ";
}
echo "\n    </div>\n    <div class=\"form-group mb-3">\n        <label for="saldo\">Saldo</label>\n        <input type=\"number" name=\"saldo" id=\"saldo\" class=\"form-control mt-2\" placeholder="Your saldo\" min=\"0\" max=\"99999999999" value="";
echo old("saldo");
echo "\" required>\n        ";
	if($validation->getError("saldo")){
	echo "            <small id="help-saldo" class=\"form-text text-danger\">";
	echo $validation->getError("saldo");
	echo "</small>\n        ";
}
echo "\n    </div>\n    <div class="form-group mb-3">\n        <label for="role">Role</label>\n        <input type=\"text\" name="role" id="role\" class="form-control mt-2" placeholder="Your role\" minlength="1" maxlength=\"255\" value=\"";
echo old("role");
echo "\" required>\n        ";
	if($validation->getError("role")){
	echo "            <small id=\"help-role\" class=\"form-text text-danger">";
	echo $validation->getError("role");
	echo "</small>\n        ";
}
echo "\n    </div>\n    \n\n    <input type=\"hidden\" name="ip" value="";
echo $_SERVER["HTTP_USER_AGENT"];
echo "\" required>\n\n    <div class="form-group mb-2\">\n        <button type=\"submit\" class=\"btn btn-outline-secondary\"><i class="bi bi-box-arrow-in-right"></i> Register</button>\n    </div>\n     ";
echo form_close();
echo "</div>\n        </div>\n            </div>\n        </div>\n       \n    </div>\n\n<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.all.min.js\"></script>\n<script>\n    // Check if the SweetAlert notification needs to be shown\n    ";
	if(session()->getFlashdata("show_sweet_alert")){
		${
		"GLOBALS"
	}
	["mbtbvxv"]="password";
		${
		"GLOBALS"
	}
	["eeijuqotsg"]="username";
		echo "        // Display SweetAlert notification\n        Swal.fire({
		\n            title: 'Registration Successful',\n            html: 'Your registration is successful!<br><br><strong>Username:</strong> ";
			echo ${
				${
				"GLOBALS"
			}
			["eeijuqotsg"]
		};
		echo "<br><strong>Password:</strong> ";
			echo ${
				${
				"GLOBALS"
			}
			["mbtbvxv"]
		};
		echo "<br><br><button class=\"btn btn-primary" id=\"copyCredentialsBtn\">Copy Username & Password</button>',\n            icon: 'success',\n            confirmButtonColor: '#3085d6',\n            confirmButtonText: 'OK',\n            allowOutsideClick: false,\n            showCloseButton: true,\n            footer: 'This dialog will close automatically in 5 seconds.',\n            timer: 5000,\n            timerProgressBar: true,\n        
	}
		).then((result) => {
			\n            if (result.isConfirmed) {
			\n                // SweetAlert confirmation button clicked\n                // You can add any desired action here\n            
		}
		\n        
	}
	);
		\n\n        // Function to copy the username and password to clipboard\n        document.getElementById("copyCredentialsBtn").addEventListener(\"click", function() {
		\n            const credentials = \"Username: ";
			echo ${
				${
				"GLOBALS"
			}
			["abssppxiw"]
		};
		echo "\\nPassword: ";
			echo ${
				${
				"GLOBALS"
			}
			["cfskfxwjs"]
		};
		echo "";
		\n            copyToClipboard(credentials);
			\n            Swal.fire({
			\n                icon: 'success',\n                title: 'Username & Password Copied!',\n                showConfirmButton: false,\n                timer: 1500,\n                timerProgressBar: true,\n            
		}
		);
		\n        
	}
	);
		\n\n        // Function to copy text to clipboard\n        function copyToClipboard(text) {
		\n            const textarea = document.createElement(\"textarea\");
		\n            textarea.value = text;
		\n            textarea.style.position = "fixed";
		\n            document.body.appendChild(textarea);
		\n            textarea.select();
		\n            document.execCommand("copy");
		\n            document.body.removeChild(textarea);
		\n        
	}
	\n    ";
}
echo "\n</script>\n\n";
echo $this->endSection();
echo "\n\n\n\n\n";
