echo "<head>\n  <meta charset="UTF-8\">\n  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge">\n  <meta name=\"viewport" content=\"width=device-width, initial-scale=1.0\">\n  <title>FallenX - Gaming Panel</title>\n\n  \n  <link rel="shortcut icon\" href="./favicon.svg" type=\"image/svg+xml\">\n\n  \n  <link rel="stylesheet\" href=\"./assets/css/style.css">\n\n  \n  <link rel="preconnect\" href="https://fonts.googleapis.com">\n  <link rel="preconnect\" href="https://fonts.gstatic.com" crossorigin>\n  <link\n    href="https://fonts.googleapis.com/css2?family=Oswald:wght@300;
400;
500;
600;
700&family=Poppins:wght@400;
500;
	700&display=swap\"\n    rel=\"stylesheet\">\n</head>\n\n<style>\n  \n  @media (max-width: 767px) {
		\n    .dropdown-menu {
		\n      max-height: 200px;
		 \n      overflow-y: auto;
		 \n    
	}
	\n  
}
	\n  \n  .new-class img {
	\n  width: 100px;
	 \n  height: auto;
	 \n
}
\n</style>\n \n<body id=\"top\">\n\n  \n\n  <header class="header">\n\n    \n    <div class=\"overlay\" data-overlay></div>\n\n    <div class=\"container\">\n\n     <a href="#" class=\"logo new-class">\n  <img src="./assets/images/project.png" alt=\"FallenX logo\">\n</a>\n\n      <button class="nav-open-btn\" data-nav-open-btn>\n        <ion-icon name="menu-outline"></ion-icon>\n      </button>\n\n    <nav class="navbar" data-nav>\n\n  <div class="navbar-top">\n\n    <a href="#" class=\"logo new-class\">\n  <img src="./assets/images/project.png\" alt=\"FallenX logo\">\n</a>\n\n    <button class="nav-close-btn" data-nav-close-btn>\n      <ion-icon name="close-outline"></ion-icon>\n    </button>\n\n  </div>\n\n        <ul class="navbar-list\">\n\n          <li>\n            <a href="";
echo site_url("dashboard");
echo "" class="navbar-link">Home</a>\n          </li>\n\n          <li>\n            <a href="";
echo site_url("keys");
echo "" class="navbar-link">Key</a>\n          </li>\n\n          <li>\n            <a href="";
echo site_url("keys/generate");
echo "\" class="navbar-link\">Generate</a>\n          </li>\n          \n          <li>\n            <a href=\"";
echo site_url("Server");
echo "\" class="navbar-link\">Server</a>\n          </li>\n         \n          <li>\n            <a href="";
echo site_url("admin/create-referral");
echo "" class="navbar-link">Referral</a>\n          </li>\n          \n          <li>\n            <a href=\"";
echo site_url("admin/manage-users");
echo "\" class=\"navbar-link\">Manage</a>\n          </li>\n\n           <li class="dropdown\">\n       <a href="#\" class="navbar-link">More</a>\n        <ul class="dropdown-menu\">\n        <li>\n          <a class=\"nav-link" href="";
echo site_url("ResetKey");
echo "\">Reset Key</a>\n        </li>\n        <li>\n          <a class=\"nav-link\" href="";
echo site_url("Bypass");
echo "">Online Bypass</a>\n        </li>\n         <li>\n          <a class="nav-link\" href="";
echo site_url("resetPassword");
echo "\">Passsword Reset</a>\n        </li>\n        <li>\n          <a class="nav-link\" href=\"";
echo site_url("upload");
echo "">Online Lib</a>\n        </li>\n        \n       \n      </ul>\n    </li>\n\n        </ul>\n\n        <ul class="nav-social-list">\n\n          <li>\n            <a href=\"#" class=\"social-link\">\n              <ion-icon name="logo-twitter"></ion-icon>\n            </a>\n          </li>\n\n          <li>\n            <a href=\"#" class="social-link\">\n              <ion-icon name=\"logo-instagram\"></ion-icon>\n            </a>\n          </li>\n\n          <li>\n            <a href=\"#" class=\"social-link\">\n              <ion-icon name=\"logo-github"></ion-icon>\n            </a>\n          </li>\n\n         <li>\n  <a href="";
echo site_url("logout");
echo "" class=\"social-link\">\n    ➡️ Sign Out\n  </a>\n</li>\n\n        </ul>\n\n      </nav>\n\n      <div class="header-actions">\n\n        <button class=\"search\">\n          <ion-icon name=\"search-outline"></ion-icon>\n        </button>\n\n       <button class=\"btn-sign_in" onclick="window.location.href='";
echo site_url("logout");
	echo "'\">\n\n  <div class="icon-box\">\n    <ion-icon name=\"log-in-outline"></ion-icon>\n  </div>\n\n  <span>Sign Out</span>\n\n</button>\n\n\n      </div>\n\n    </div>\n\n  </header>\n  <script>\n  document.addEventListener("DOMContentLoaded\", function () {
	\n    var dropdownLinks = document.querySelectorAll(".dropdown .navbar-link");
	\n    var dropdownMenus = document.querySelectorAll(\".dropdown .dropdown-menu\");
		\n\n    // Function to toggle the dropdown menu\n    function toggleDropdown(dropdownMenu) {
		\n      var display = window.getComputedStyle(dropdownMenu).display;
		\n      dropdownMenu.style.display = display === \"block\" ? "none" : "block";
		\n    
	}
		\n\n    // Toggle the dropdown menu when the \"More" link is clicked (desktop)\n    dropdownLinks.forEach(function (link) {
			\n      link.addEventListener("click", function (event) {
			\n        event.preventDefault();
			\n        event.stopPropagation();
			\n        var dropdownMenu = this.nextElementSibling;
			\n        toggleDropdown(dropdownMenu);
			\n      
		}
		);
		\n    
	}
	);
		\n\n    // Handle touch interactions for the "More\" link (mobile)\n    dropdownLinks.forEach(function (link) {
			\n      link.addEventListener("touchstart", function (event) {
			\n        event.preventDefault();
			\n        event.stopPropagation();
			\n        var dropdownMenu = this.nextElementSibling;
			\n        toggleDropdown(dropdownMenu);
			\n      
		}
		);
		\n    
	}
	);
		\n\n    // Prevent the dropdown from closing when clicking inside the dropdown menu\n    dropdownMenus.forEach(function (menu) {
			\n      menu.addEventListener("click", function (event) {
			\n        event.stopPropagation();
			\n      
		}
		);
			\n\n      // Close the dropdown when clicking outside of it (desktop)\n      document.addEventListener("click", function (event) {
			\n        var dropdowns = document.getElementsByClassName("dropdown\");
			\n        for (var i = 0;
			 i < dropdowns.length;
				 i++) {
				\n          var dropdownMenu = dropdowns[i].querySelector(".dropdown-menu\");
					\n          if (!dropdowns[i].contains(event.target)) {
					\n            dropdownMenu.style.display = \"none\";
					\n          
				}
				\n        
			}
			\n      
		}
		);
		\n    
	}
	);
	\n  
}
);
\n</script>\n  <script src="assets/js/script.js\"></script>\n\n  <script type=\"module\" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js\"></script>\n  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>\n";



