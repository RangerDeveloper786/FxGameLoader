echo "<!doctype html>\n<html lang="en">\n<style>\n \n</style>\n<head>\n    \n    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css\" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC\" crossorigin="anonymous">\n    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css\" rel=\"stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+UPmUSVOJXQOqa1Je7GOmMaXZzZtoUAOaEvKFVpEEj0fzZt\" crossorigin=\"anonymous">\n\n    <link rel=\"preconnect" href="https://fonts.googleapis.com">\n  <link rel=\"preconnect" href="https://fonts.gstatic.com" crossorigin>\n  <link\n    href=\"https://fonts.googleapis.com/css2?family=Oswald:wght@300;
400;
500;
600;
700&family=Poppins:wght@400;
500;
700&display=swap"\n    rel="stylesheet">\n\n    <title>";
echo BASE_NAME;
echo " - ";
$qwpgivqulf="title";
$rqcbskny="title";
	echo isset(${
	$rqcbskny
}
	)?${
	$qwpgivqulf
}
:"Panel";
echo "</title>\n    ";
echo $this->renderSection("css");
echo "\n    ";
echo link_tag("assets/css/natacode.css");
echo "    ";
echo link_tag("assets/css/Style.css");
echo "    ";
echo script_tag("assets/js/Style.css");
	echo "    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity=\"sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous\"></script>\n</head>\n\n<style>\n  \n\n  \n  .new-class img {
	\n  width: 200px;
	 \n  height: auto;
	 \n
}
\n</style>\n<body >\n    \n    ";
echo $this->include("Layout/Header");
echo "    \n    <main>\n        <div class=\"container p-3 py-4 mb-3\" id=\"content">\n            \n            ";
echo $this->renderSection("content");
echo "\n            \n        </div>\n    </main>\n    \n    \n    <footer>\n\n  <footer>\n\n    <div class=\"footer-top">\n      <div class=\"container\">\n\n        <div class="footer-brand-wrapper">\n\n           <a href="#\" class="logo new-class">\n  <img src=\"./assets/images/project.png" alt=\"FallenX logo">\n</a>\n\n          <div class=\"footer-menu-wrapper">\n\n            <ul class="footer-menu-list">\n\n              <li>\n                 <a  class="footer-menu-link\" href="";
echo site_url("keys");
echo "\">Keys</a>\n              </li>\n\n              <li>\n                 <a class=\"footer-menu-link" href="";
echo site_url("keys/generate");
echo "">Generate</a>\n              </li>\n\n              <li>\n                <a class=\"footer-menu-link\" href=\"";
echo site_url("Server");
echo "">Online System</a>\n              </li>\n\n              <li>\n                 <a class="footer-menu-link\" href="";
echo site_url("Bypass");
echo "\">Online Bypass</a>\n              </li>\n\n              <li>\n                 <a class=\"footer-menu-link\" href=\"";
echo site_url("resetPassword");
echo "\">Password Reset</a>\n              </li>\n\n              <li>\n                <a href=\"#\" class=\"footer-menu-link\">Contact</a>\n              </li>\n\n            </ul>\n\n            <div class="footer-input-wrapper\">\n              <input type="text\" name=\"message\" required placeholder="Find Here Now\" class="footer-input">\n\n              <button class=\"btn btn-primary\">\n                <ion-icon name=\"search-outline"></ion-icon>\n              </button>\n            </div>\n\n          </div>\n\n        </div>\n\n        <div class=\"footer-quicklinks">\n\n          <ul class=\"quicklink-list">\n\n            <li>\n              <a href="#\" class=\"quicklink-item\">Faq</a>\n            </li>\n\n            <li>\n              <a href="#" class=\"quicklink-item">Help center</a>\n            </li>\n\n            <li>\n              <a href="#\" class="quicklink-item">Terms of use</a>\n            </li>\n\n            <li>\n              <a href="#" class=\"quicklink-item">Privacy</a>\n            </li>\n\n          </ul>\n\n          <ul class=\"footer-social-list">\n\n            <li>\n              <a href="#\" class=\"footer-social-link\">\n                <ion-icon name=\"logo-discord"></ion-icon>\n              </a>\n            </li>\n\n            <li>\n              <a href=\"#\" class="footer-social-link">\n                <ion-icon name=\"logo-twitch"></ion-icon>\n              </a>\n            </li>\n\n            <li>\n              <a href="#\" class=\"footer-social-link\">\n                <ion-icon name=\"logo-xbox"></ion-icon>\n              </a>\n            </li>\n\n            <li>\n              <a href=\"#\" class="footer-social-link">\n                <ion-icon name=\"logo-youtube\"></ion-icon>\n              </a>\n            </li>\n\n          </ul>\n\n        </div>\n\n      </div>\n    </div>\n\n    <div class=\"footer-bottom">\n      <div class=\"container\">\n        <p class=\"copyright">\n          Copyright &copy;
 2022 <a href=\"#\">Offensive</a>. all rights reserved\n        </p>\n\n        <figure class=\"footer-bottom-img">\n          <img src="./assets/images/footer-bottom-img.png\" alt=\"Online payment companies logo">\n        </figure>\n      </div>\n    </div>\n\n  </footer>\n   <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-Dziyf5hFm7P2qzFQUvEoC4KCZnQApFmCwG5wALv/O9vYzwxIka7jU2yG5FfJ4p8k\" crossorigin="anonymous"></script>\n<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity=\"sha384-AbhknbwMfOiN4Q5mi8L8aB1iuXl8Ct6F9l8bX8IcfxiFz7dV8BGSX8T3l02oJr7F\" crossorigin=\"anonymous"></script>\n<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity=\"sha384-1ss8GKvlzGYJlLPJW8mNEu6/s9CaQ3XqSl1n9Xw5d9iiRH6I8U8Htvu1Zi4fC73F" crossorigin="anonymous\"></script>\n   \n    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM\" crossorigin="anonymous"></script>\n    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.1.0/sweetalert2.all.min.js" integrity="sha512-0UUEaq/z58JSHpPgPv8bvdhHFRswZzxJUT9y+Kld5janc9EWgGEVGfWV1hXvIvAJ8MmsR5d4XV9lsuA90xXqUQ==" crossorigin="anonymous\" referrerpolicy=\"no-referrer"></script>\n\n    ";
echo script_tag("assets/js/natacode.js");
echo "     ";
echo script_tag("assets/js/script.js");
echo "\n    ";
echo $this->renderSection("js");
echo "\n</body>\n\n</html>\n";



