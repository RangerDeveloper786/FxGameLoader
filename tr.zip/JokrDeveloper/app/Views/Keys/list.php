echo $this->extend("Layout/Starter");
echo "\n";
	${
	"GLOBALS"
}
["kdfnzicqis"]="keylist";
echo $this->section("content");
	echo "<div class="row justify-content-center\">\n   \n\n\n<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-Dziyf5hFm7P2qzFQUvEoC4KCZnQApFmCwG5wALv/O9vYzwxIka7jU2yG5FfJ4p8k" crossorigin=\"anonymous"></script>\n\n<style>\n    \n    .about-content {
	\n    max-width: 1117px;
	\n    margin-inline: 0;
	\n    \n    \n
}
	\n.btn {
	\n        background-color: beige;
	\n    color: black;
	\n    font-family: var(--ff-oswald);
	\n    font-size: x-small;
	\n    letter-spacing: 1px;
	\n    text-transform: uppercase;
	\n    display: flex;
	\n    justify-content: center;
	\n    align-items: center;
	\n    gap: 10px;
	\n    padding: 6px 34px;
	\n    clip-path: var(--polygon-1);
	\n    transition: var(--transition-1);
	\n
}
	\n\n.text-dark {
	\n    color: #dfb535!important;
	\n
}
\n</style>\n\n<div class="section-wrapper">\n\n        \n\n        <section class=\"about\" id=\"about\">\n         \n\n           \n\n          <div class=\"about-content">\n\n              <p class=\"about-subtitle\">Welcome Bro</p>\n\n              <h2 class="about-title\">Key History And  <strong>User Information</strong> </h2>\n\n              <div class=\"card-body\">\n                 ";
	if(${
		${
		"GLOBALS"
	}
	["kdfnzicqis"]
}
	){
	echo "                        <div class=\"table-responsive">\n                            \n                            \n                           <table id=\"datatable" class="table table-bordered table-hover text-center" style="width:100%\">\n                                <thead>\n                                    <tr>\n                                        <th>#</th>\n                                        <th>Game</th>\n                                        <th>User Keys</th>\n                                        <th>Devices</th>\n                                        <th>Duration</th>\n                                        <th>Status</th>\n                                        <th>Expired</th>\n                                        <th>Action</th>\n                                    </tr>\n                                </thead>\n                            </table>\n                        </div>\n                    ";
}
	else{
	echo "                        <p class="text-center">Nothing keys to show</p>\n                    ";
}
echo "\n                    \n                    \n     <div class="col-lg-6\">\n    <div class="card mb-3\">\n     \n     <div class=\"section-wrapper\">\n\n            <div class=\"about-content\">\n\n             \n\n              <h2 class="about-title\">Manage   <strong>Keys</strong> </h2>\n\n               <div class=\"card-body" style=\"padding-bottom:130px;
">\n        <div class="d-grid">\n <a href=\"";
echo site_url("keys/alter");
echo "\" class="btn btn-outline-dark btn-lg\"><i class="bi bi-bookmark-plus"></i> Expired Delete</a>\n</div>\n<br>\n\n<div class="d-grid">\n <a href=\"";
echo site_url("keys/deleteKeys");
echo "\" class=\"btn btn-outline-dark btn-lg"><i class=\"bi bi-bookmark-plus\"></i> Delete All</a>\n</div>\n<br>\n<div class="d-grid\">\n <a href=\"";
echo site_url("keys/start");
echo "\" class=\"btn btn-outline-dark btn-lg"><i class="bi bi-bookmark-plus\"></i>Never Used</a>\n</div>\n<br>\n<div class=\"d-grid\">\n <a href="";
echo site_url("keys/resetAll");
echo "\" class="btn btn-outline-dark btn-lg"><i class="bi bi-bookmark-plus\"></i>Reset All</a>\n</div>\n<br>\n<div class="d-grid">\n <a href="";
echo site_url("keys/download/all");
echo "\" class="btn btn-outline-dark btn-lg"><i class=\"bi bi-bookmark-plus\"></i>Download All</a>\n</div>\n\n<br>\n<div class=\"d-grid">\n <a href=\"";
echo site_url("keys/download/new");
echo "" class="btn btn-outline-dark btn-lg"><i class="bi bi-bookmark-plus"></i>Download New All</a>\n</div>\n<br>\n<div class=\"d-grid">\n    <a href=\"";
echo site_url("keys/active");
echo "\" class="btn btn-outline-dark btn-lg\">\n        <i class="bi bi-bookmark-plus\"></i> Update Keys as Active\n    </a>\n</div>\n<br>\n<div class="d-grid">\n    <a href=\"";
echo site_url("keys/inactive");
echo "\" class="btn btn-outline-dark btn-lg\">\n        <i class="bi bi-bookmark-minus\"></i> Update Keys as Inactive\n    </a>\n</div>\n<br>\n           \n    </div>\n              <p class="about-bottom-text">\n                <ion-icon name=\"arrow-forward-circle-outline"></ion-icon>\n\n                <span>This will download the key</span>\n              </p>\n\n            </div>\n\n          </div>\n        </section>\n        </div>\n    </div>\n                </div>   \n            </div>\n            \n              <div class=\"card-body">\n              \n            </div>\n\n              <p class=\"about-bottom-text\">\n                <ion-icon name="arrow-forward-circle-outline\"></ion-icon>\n\n                <span>Will sharpen your brain and focus</span>\n              </p>\n\n            </div>\n\n          </div>\n        </section>\n";
echo $this->endSection();
echo "\n";
echo $this->section("css");
echo "\n\n";
echo link_tag("https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css");
echo "\n";
echo $this->endSection();
echo "\n";
echo $this->section("js");
echo script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js");
echo "\n";
echo script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js");
	echo "\n\n<script>\n    \$(document).ready(function() {
		\n        var table = \$('#datatable').DataTable({
		\n            processing: true,\n            serverSide: true,\n            order: [\n                [0, "desc\"]\n            ],\n            ajax: \"";
		echo site_url("keys/api");
			echo "\",\n            columns: [{
			\n                    data: 'id',\n                    name: 'id_keys'\n                
		}
			,\n                {
			\n                    data: 'game',\n                
		}
			,\n                {
				\n                    data: 'user_key',\n                    render: function(data, type, row, meta) {
				\n                        var is_valid = (row.status == 'Active') ? \"text-success\" : "text-danger";
					\n                        return `<span class=\"\${
					is_valid
				}
					 keyBlur key-sensi">\${
					(row.user_key ? row.user_key : '&mdash;
					')
				}
				</span> `;
				\n                    
			}
			\n                
		}
			,\n                {
				\n                    data: 'devices',\n                    render: function(data, type, row, meta) {
				\n                        var totalDevice = (row.devices ? row.devices : 0);
					\n                        return `<span id="devMax-\${
					row.user_key
				}
					">\${
					totalDevice
				}
					/\${
					row.max_devices
				}
				</span>`;
				\n                    
			}
			\n                
		}
			,\n                {
				\n                    data: 'duration',\n                    render: function(data, type, row, meta) {
				\n                        return row.duration;
				\n                    
			}
			\n                
		}
			,\n                \n                {
				\n                    data: 'status',\n                    render: function(data, type, row, meta) {
				\n                        return row.status;
				\n                    
			}
			\n                
		}
			,\n                {
				\n                    data: 'expired',\n                    name: 'expired_date',\n                    render: function(data, type, row, meta) {
					\n                        return row.expired ? `<span class="badge text-dark">\${
					row.expired
				}
				</span>` : '(not started yet)';
				\n                    
			}
			\n                
		}
			,\n                {
				\n                  data: null,\n                    render: function(data, type, row, meta) {
					\n                        var btnReset = `<button class="btn btn-outline-warning btn-sm" onclick=\"resetUserKey('\${
					row.user_key
				}
				')\"\n                        data-bs-toggle=\"tooltip\" data-bs-placement=\"left" title="Reset key?"><i class="bi bi-bootstrap-reboot"></i></button>`;
					\n\n                       \n                        \n                        var btnEdits = `<a href="\${
					window.location.origin
				}
					/keys/\${
					row.id
				}
				" class="btn btn-outline-dark btn-sm\"\n                        data-bs-toggle=\"tooltip" data-bs-placement="left\" title=\"Edit key information?"><i class="bi bi-gear\"></i></a>`;
					\n                        \n                        \n                        var btnDelete = `<button class="btn btn-outline-danger btn-sm" onclick=\"deleteKeys('\${
					row.user_key
				}
				')\"\n                        data-bs-toggle="tooltip" data-bs-placement=\"left\" title=\"Delete Key?\"><i class=\"bi bi-trash"></i></button>`;
					\n\n\n                        \n                        return `<div class="d-grid gap-2 d-md-block\">\${
					btnReset
				}
					 \${
					btnEdits
				}
					 \${
					btnDelete
				}
				</div>`;
				\n                    
			}
			\n                
		}
		\n            ]\n        
	}
	);
		\n\n        \$(\"#blur-out\").click(function() {
			\n            if (\$(\".keyBlur\").hasClass("key-sensi\")) {
			\n                \$(".keyBlur").removeClass("key-sensi\");
			\n                \$(\"#blur-out").html(`<i class="bi bi-eye\"></i>`);
			\n            
		}
			 else {
			\n                \$(\".keyBlur").addClass(\"key-sensi");
			\n                \$(\"#blur-out\").html(`<i class="bi bi-eye-slash"></i>`);
			\n            
		}
		\n        
	}
	);
	\n    
}
);
	\n\n\n function deleteKeys(keys) {
		\n        Swal.fire({
		\n            title: 'Are you sure?',\n            text: \"You won't be able to revert this!\",\n            icon: 'warning',\n            showCancelButton: true,\n            confirmButtonColor: '#3085d6',\n            cancelButtonColor: '#d33',\n            confirmButtonText: 'Yes, delete'\n        
	}
		).then((result) => {
			\n            if (result.isConfirmed) {
				\n                Toast.fire({
				\n                    icon: 'info',\n                    title: 'Please wait...'\n                
			}
			)\n\n                var base_url = window.location.origin;
				\n                var api_url = `\${
				base_url
			}
			/keys/delete`;
				\n                \$.getJSON(api_url, {
				\n                        userkey: keys,\n                        delete: 1\n                    
			}
				,\n                    function(data, textStatus, jqXHR) {
					\n                        if (textStatus == 'success') {
						\n                            if (data.registered) {
							\n                                if (data.delete) {
								\n                                    \$(`#devMax-\${
								keys
							}
								`).html(`0/\${
								data.devices_max
							}
							`);
							\n                                    Swal.fire(\n                                        'Deleted!',\n                                        'Redirecting to Key Dashboard.',\n                                        'success'\n                                        \n\n                                    )\n                                    location.reload()\n\n                                
						}
							 else {
							\n                                    Swal.fire(\n                                        'Failed!',\n                                        data.devices_total ? \"You don't have any access to this user." : "Only Admin can delete the user.",\n                                        data.devices_total ? 'error' : 'error'\n                                        \n                                    )\n                                
						}
						\n                            
					}
						 else {
						\n                                Swal.fire(\n                                    'Failed!',\n                                    \"User key no longer exists.\",\n                                    'error'\n                                )\n                            
					}
					\n                        
				}
				\n                    
			}
			\n                );
			\n            
		}
		\n        
	}
	);
	\n    
}
	\n\n\n   function resetUserKey(keys) {
		\n        Swal.fire({
		\n            title: 'Are you sure?',\n            text: "You won't be able to revert this!",\n            icon: 'warning',\n            showCancelButton: true,\n            confirmButtonColor: '#3085d6',\n            cancelButtonColor: '#d33',\n            confirmButtonText: 'Yes, reset'\n        
	}
		).then((result) => {
			\n            if (result.isConfirmed) {
				\n                Toast.fire({
				\n                    icon: 'info',\n                    title: 'Please wait...'\n                
			}
			)\n\n                var base_url = window.location.origin;
				\n                var api_url = `\${
				base_url
			}
			/keys/reset`;
				\n                \$.getJSON(api_url, {
				\n                        userkey: keys,\n                        reset: 1\n                    
			}
				,\n                    function(data, textStatus, jqXHR) {
					\n                        if (textStatus == 'success') {
						\n                            if (data.registered) {
							\n                                if (data.reset) {
								\n                                    \$(`#devMax-\${
								keys
							}
								`).html(`0/\${
								data.devices_max
							}
							`);
							\n                                    Swal.fire(\n                                        'Reset!',\n                                        'Your device key has been reset.',\n                                        'success'\n                                    )\n                                
						}
							 else {
							\n                                    Swal.fire(\n                                        'Failed!',\n                                        data.devices_total ? "You don't have any access to this user." : \"User key devices already reset.",\n                                        data.devices_total ? 'error' : 'warning'\n                                    )\n                                
						}
						\n                            
					}
						 else {
						\n                                Swal.fire(\n                                    'Failed!',\n                                    \"User key no longer exists.\",\n                                    'error'\n                                )\n                            
					}
					\n                        
				}
				\n                    
			}
			\n                );
			\n            
		}
		\n        
	}
	);
	\n    
}
\n</script>\n\n\n";
echo $this->endSection();



