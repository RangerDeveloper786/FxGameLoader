	${
	"GLOBALS"
}
["hoehcnle"]="price";
	${
	"GLOBALS"
}
["wxnomcjmu"]="game";
echo $this->extend("Layout/Starter");
echo "\n";
echo $this->section("content");
	echo "<div class="row justify-content-center\">\n   \n\n\n<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity=\"sha384-Dziyf5hFm7P2qzFQUvEoC4KCZnQApFmCwG5wALv/O9vYzwxIka7jU2yG5FfJ4p8k" crossorigin=\"anonymous"></script>\n\n<style>\n    \n    .about-content {
	\n    max-width: 1117px;
	\n    margin-inline: 0;
	\n    \n    \n
}
	\n    \n<style>\n    \n    .btn {
	\n     background-color: beige;
	\n    color: black;
	\n    font-family: var(--ff-oswald);
	\n    font-size: var(--fs-6);
	\n    font-weight: var(--fw-500);
	\n    letter-spacing: 1px;
	\n    text-transform: uppercase;
	\n    display: flex;
	\n    justify-content: center;
	\n    align-items: center;
	\n    gap: 10px;
	\n    padding: 13px 34px;
	\n    clip-path: var(--polygon-1);
	\n    transition: var(--transition-1);
	\n   
}
\n</style>\n\n      ";
	if(session()->getFlashdata("user_key")){
	echo "    <div class="alert alert-success\" role="alert">\n        Game: ";
	echo session()->getFlashdata("game");
	echo " / ";
	echo session()->getFlashdata("duration");
	echo " Days<br>\n        License: <strong class=\"">";
	echo session()->getFlashdata("user_key");
	echo "</strong><br>\n        <small>\n            <i>Duration will start when license login.</i><br>\n           \n            Balance Remaining -> ";
	echo $user->saldo-session()->getFlashdata("fees");
	echo "\$\n        </small>\n    </div>\n";
}
echo "\n<div class=\"row justify-content-center\">\n    <div class=\"col-lg-6\">\n <div class=\"section-wrapper\">\n \n        \n\n        <section class="about\" id=\"about">\n         \n\n\n            <div class="about-content\">\n\n              <p class="about-subtitle">Generate </p>\n\n              <h2 class=\"about-title">User <strong>Licence </strong> </h2>\n\n              <div class=\"card-body\">\n                  ";
$vndbnsed="duration";
echo form_open();
echo "\n       <div class=\"row\">\n    <div class="form-group col-lg-6 mb-3\">\n        <label for="game\" class="form-label\">Games</label>\n        ";
	echo form_dropdown(["class"=>"form-select","name"=>"game","id"=>"game"],${
		${
		"GLOBALS"
	}
	["wxnomcjmu"]
}
,old("game")?:"");
echo "        ";
	if($validation->hasError("game")){
	echo "            <small id="help-game" class=\"text-danger">";
	echo $validation->getError("game");
	echo "</small>\n        ";
}
echo "\n    </div>\n    <div class="form-group col-lg-6 mb-3\">\n        <label for="max_devices\" class="form-label\">Max Devices</label>\n        <input type="number" name=\"max_devices" id=\"max_devices\" class=\"form-control\" placeholder=\"1\" value="";
echo old("max_devices")?:1;
echo "">\n        ";
	if($validation->hasError("max_devices")){
	echo "            <small id=\"help-max_devices\" class="text-danger">";
	echo $validation->getError("max_devices");
	echo "</small>\n        ";
}
echo "\n    </div>\n</div>\n<div class="form-group mb-3\">\n    <label for=\"duration\" class=\"form-label\">Duration</label>\n    ";
	echo form_dropdown(["class"=>"form-select","name"=>"duration","id"=>"duration"],${
	$vndbnsed
}
,old("duration")?:"");
echo "    ";
	if($validation->hasError("duration")){
	echo "        <small id="help-duration\" class=\"text-danger\">";
	echo $validation->getError("duration");
	echo "</small>\n    ";
}
echo "\n</div>\n<div class="form-group mb-3">\n    <label for=\"count\" class=\"form-label\">Number of Keys</label>\n    <input type=\"number\" name="count\" id="count\" class=\"form-control" placeholder=\"1" value=\"";
echo old("count")?:1;
echo "">\n    ";
	if($validation->hasError("count")){
	echo "        <small id="help-count" class="text-danger\">";
	echo $validation->getError("count");
	echo "</small>\n    ";
}
echo "\n</div>\n\n <div class=\"form-group mb-3">\n        <label for=\"manual_key_name\">Manual Key Name (optional):</label>\n        <input type="text" class="form-control\" id=\"manual_key_name\" name="manual_key_name">\n    </div>\n<div class=\"form-group mb-3\">\n    <label for="estimation" class="form-label\">Estimation</label>\n    <input type=\"text" id="estimation" class=\"form-control\" placeholder="Your order will total" readonly>\n</div>\n<div class=\"form-group">\n    <button type="submit\" class=\"btn btn-outline-dark">Generate</button>\n</div>\n        ";
echo form_close();
echo "            </div>\n\n \n            \n\n          </div>\n        </section>\n       \n</div>\n\n\n";
echo $this->endSection();
echo "\n";
echo $this->section("js");
	echo "<script>\n    \$(document).ready(function() {
	\n        var price = JSON.parse('";
		echo ${
			${
			"GLOBALS"
		}
		["hoehcnle"]
	};
	echo "');
	\n        getPrice(price);
		\n        // When selected\n        \$("#max_devices, #duration, #game, #count\").change(function() {
		\n            getPrice(price);
		\n        
	}
	);
		\n        // try to get price\n        function getPrice(price) {
		\n            var device = parseInt(\$(\"#max_devices").val());
		\n            var durate = parseInt(\$(\"#duration\").val());
		\n            var count = parseInt(\$(\"#count\").val());
		\n            var gprice = price[durate];
			\n            if (gprice != NaN) {
			\n                var result = (device * gprice * count);
			\n                \$("#estimation").val(result.toFixed(2));
			\n            
		}
			 else {
			\n                \$("#estimation\").val('Estimation error');
			\n            
		}
		\n        
	}
	\n    
}
);
\n</script>\n\n\n<script>\n    // Check if there are generated keys in session and display sweet alert\n    ";
	if(session()->getFlashdata("user_keys")){
	echo "        const keysData = ";
	echo json_encode(session()->getFlashdata("user_keys"));
	echo ";
	\n        let keysHtml = '';
		\n        keysData.forEach(key => {
			\n            keysHtml += `<p><strong>Game:</strong> \${
			key.game
		}
			 / <strong>Duration:</strong> \${
			key.duration
		}
			 Days<br>\n                <strong>License:</strong> \${
			key.user_key
		}
		<br>\n                <small><i>Duration will start when license login.</i></small></p>`;
		\n        
	}
	);
		\n\n        Swal.fire({
		\n            title: 'Successfully generated keys',\n            html: keysHtml,\n            icon: 'success',\n            confirmButtonText: 'Copy Keys',\n            showCancelButton: true,\n        
	}
		).then((result) => {
			\n            if (result.isConfirmed) {
			\n                // Create a temporary text area to copy the keys\n                const tempTextArea = document.createElement('textarea');
			\n                tempTextArea.style.position = 'fixed';
			\n                tempTextArea.style.opacity = 0;
			\n                document.body.appendChild(tempTextArea);
			\n\n                // Combine all keys into a single string\n                const allKeys = keysData.map(key => key.user_key).join('\n');
			\n                tempTextArea.value = allKeys;
			\n\n                // Select and copy the keys to clipboard\n                tempTextArea.select();
			\n                document.execCommand('copy');
			\n\n                // Remove the temporary text area\n                document.body.removeChild(tempTextArea);
				\n\n                Swal.fire({
				\n                    title: 'Keys copied to clipboard',\n                    text: 'You can now paste the keys wherever you want.',\n                    icon: 'success',\n                    timer: 3000, // Show for 3 seconds\n                    timerProgressBar: true,\n                
			}
			);
			\n            
		}
		\n        
	}
	);
	\n\n        // Clear the session after displaying the alert\n        ";
	echo session()->remove("user_keys");
	echo "    ";
}
echo "\n</script>\n";
echo $this->endSection();



