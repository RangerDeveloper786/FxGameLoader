	${
	"GLOBALS"
}
["dudsxfft"]="feature";
	${
	"GLOBALS"
}
["roikzssy"]="features";
	${
	"GLOBALS"
}
["xgoknebhbzh"]="radioLabel";
	${
	"GLOBALS"
}
["yckpyas"]="MasterOffensive";
	${
	"GLOBALS"
}
["gypinrkkbj"]="result5";
	${
	"GLOBALS"
}
["vpfscrkb"]="userDetails2";
	${
	"GLOBALS"
}
["rniqhmxqqcb"]="result2";
	${
	"GLOBALS"
}
["mmewwrnsh"]="sql2";
	${
	"GLOBALS"
}
["etmslirjnvl"]="sql5";
	${
	"GLOBALS"
}
["rbjehjwdi"]="result1";
	${
	"GLOBALS"
}
["wtoriktjky"]="userDetails1";
	${
	"GLOBALS"
}
["konqvgfgndc"]="sql1";
	${
	"GLOBALS"
}
["ossrrlrsu"]="conn";
include("conn.php");
	${
		${
		"GLOBALS"
	}
	["konqvgfgndc"]
}
="select * from onoff where id=11";
	${
	"result1"
}
	=mysqli_query(${
	"conn"
}
	,${
	"sql1"
}
);
	${
		${
		"GLOBALS"
	}
	["wtoriktjky"]
}
	=mysqli_fetch_assoc(${
		${
		"GLOBALS"
	}
	["rbjehjwdi"]
}
);
	${
	"GLOBALS"
}
["hglymvcyqwy"]="conn";
	${
		${
		"GLOBALS"
	}
	["mmewwrnsh"]
}
="select * from _ftext where id=1";
	${
		${
		"GLOBALS"
	}
	["rniqhmxqqcb"]
}
	=mysqli_query(${
		${
		"GLOBALS"
	}
	["ossrrlrsu"]
}
	,${
		${
		"GLOBALS"
	}
	["mmewwrnsh"]
}
);
	${
		${
		"GLOBALS"
	}
	["vpfscrkb"]
}
	=mysqli_fetch_assoc(${
	"result2"
}
);
	${
		${
		"GLOBALS"
	}
	["etmslirjnvl"]
}
="SELECT * FROM Feature WHERE id=1";
	${
	"GLOBALS"
}
["tzwgdpomwt"]="sql5";
	${
		${
		"GLOBALS"
	}
	["gypinrkkbj"]
}
	=mysqli_query(${
		${
		"GLOBALS"
	}
	["hglymvcyqwy"]
}
	,${
		${
		"GLOBALS"
	}
	["tzwgdpomwt"]
}
);
	${
		${
		"GLOBALS"
	}
	["yckpyas"]
}
	=mysqli_fetch_assoc(${
		${
		"GLOBALS"
	}
	["gypinrkkbj"]
}
);
echo "\n";
echo $this->extend("Layout/Starter");
echo "\n";
echo $this->section("content");
	echo "\n<style>\n    \n   .btn {
	\n     background-color: beige;
	\n    color: black;
	\n    font-family: var(--ff-oswald);
	\n    font-size: var(--fs-6);
	\n    font-weight: var(--fw-500);
	\n    letter-spacing: 1px;
	\n    text-transform: uppercase;
	\n    display: flex;
	\n    justify-content: center;
	\n    align-items: center;
	\n    gap: 10px;
	\n    padding: 13px 34px;
	\n    clip-path: var(--polygon-1);
	\n    transition: var(--transition-1);
	\n   
}
\n</style>\n\n\n<div class=\"row">\n  <div class=\"col-lg-12">\n    ";
echo $this->include("Layout/msgStatus");
echo "  </div>\n";
	if(session()->getFlashdata("msgSuccess")){
	echo "    <script>\n        Swal.fire('Success', '";
	echo session()->getFlashdata("msgSuccess");
	echo "', 'success');
	\n    </script>\n";
}
echo "\n\n";
	${
	"GLOBALS"
}
["rrejfb"]="row";
	if(session()->getFlashdata("success")){
	echo "    <script>\n        Swal.fire('Success', '";
	echo session()->getFlashdata("success");
	echo "', 'success');
	\n    </script>\n";
}
echo "\n\n\n\n  <div class=\"col-lg-6\">\n      \n    <div class="card mb-3">\n     \n     <div class="section-wrapper\">\n\n            <div class=\"about-content\">\n\n              <p class="about-subtitle\">Update</p>\n\n              <h2 class=\"about-title\">Online  <strong>Server</strong> </h2>\n\n               <div class="card-body">\n        ";
echo form_open();
echo "        <input type=\"hidden\" name="status_form" value="1">\n        <div class=\"form-group mb-3\">\n          <label for=\"status\">Current Status: <font size=\"2\" color="#a39c9b\">";
	echo ${
		${
		"GLOBALS"
	}
	["wtoriktjky"]
}
["status"];
echo "</font></label>\n          <div class="input-group mb-3">\n            <div class=\"input-group-prepend\">\n              <div class=\"input-group-text\">\n                <input type=\"radio" id="radio\" name="radios" value=\"1" required> <font size=\"2\">Online Server</font>\n              </div>\n            </div>\n            <div class="input-group-prepend">\n              <div class="input-group-text\">\n                <input type="radio" id=\"radio" name="radios" value="2\"> <font size=\"2\">Offline Server</font>\n              </div>\n            </div>\n          </div>\n          <label for="modname\">Current Offline Msg: <font size=\"2\" color=\"#a39c9b">";
	echo ${
		${
		"GLOBALS"
	}
	["wtoriktjky"]
}
["myinput"];
echo "</font></label>\n          <div class=\"input-group mb-3\">\n            <div class=\"input-group-prepend">\n              <span class=\"input-group-text" id=\"inputGroup-sizing-default\">Offline Msg</span>\n            </div>\n            <textarea class=\"form-control" placeholder="Enter Server Off Message\" name="myInput" id="myInput" rows="1\"></textarea>\n          </div>\n          ";
	if($validation->hasError("modname")){
	echo "            <small id=\"help-modname" class=\"text-danger\">";
	echo $validation->getError("modname");
	echo "</small>\n          ";
}
echo "\n        </div>\n        <div class=\"form-group my-2\">\n          <button type="submit\" class="btn btn-dark">Update Status</button>\n        </div>\n        ";
	${
	"GLOBALS"
}
["bgrutr"]="userDetails2";
echo form_close();
echo "      </div>\n\n              <p class=\"about-bottom-text\">\n                <ion-icon name=\"arrow-forward-circle-outline"></ion-icon>\n\n                <span>This will turn on and Off your server</span>\n              </p>\n\n            </div>\n\n          </div>\n        </section>\n        </div>\n    </div>\n    \n    \n    \n      <div class=\"col-lg-6">\n    <div class=\"card mb-3\">\n     \n     <div class="section-wrapper\">\n\n            <div class=\"about-content">\n\n              <p class=\"about-subtitle">Update</p>\n\n              <h2 class=\"about-title\">Your  <strong>ModName</strong> </h2>\n\n               <div class=\"card-body">\n        ";
echo form_open();
echo "        <input type="hidden\" name="modname_form\" value="1">\n        <div class="form-group mb-3">\n          <label for="modname\">Current Mod Name: <font size="2\" color=\"#a39c9b">";
	echo ${
		${
		"GLOBALS"
	}
	["rrejfb"]
}
["modname"];
echo "</font></label>\n          <input type="text\" name="modname" id="modname\" class="form-control mt-2" placeholder=\"Enter New Mod Name\" aria-describedby="help-modname\" required>\n          ";
	if($validation->hasError("modname")){
	echo "            <small id="help-modname\" class="text-danger">";
	echo $validation->getError("modname");
	echo "</small>\n          ";
}
echo "\n        </div>\n        <div class=\"form-group my-2\">\n          <button type=\"submit" class="btn btn-dark\">Update Mod Name</button>\n        </div>\n        ";
echo form_close();
echo "      </div>\n              <p class=\"about-bottom-text\">\n                <ion-icon name=\"arrow-forward-circle-outline"></ion-icon>\n\n                <span>This will change your Modname</span>\n              </p>\n\n            </div>\n\n          </div>\n        </section>\n        </div>\n    </div>\n\n\n \n  \n  \n    <div class="col-lg-6\">\n    <div class=\"card mb-3">\n     \n     <div class=\"section-wrapper\">\n\n            <div class="about-content\">\n\n              <p class=\"about-subtitle\">Your Online</p>\n\n              <h2 class="about-title\">ModGame <strong>Status</strong> </h2>\n\n               <div class="card-body">\n        ";
echo form_open();
echo "        <input type="hidden" name=\"_ftext\" value=\"1">\n        <label for=\"status\">Current Mod Status: <font size=\"2\" color="#a39c9b">";
	echo ${
		${
		"GLOBALS"
	}
	["bgrutr"]
}
["_status"];
echo "</font></label>\n\n        ";
	${
		${
		"GLOBALS"
	}
	["xgoknebhbzh"]
}
="<font size="2\">%s</font>";
echo "        <div class=\"input-group mb-3">\n          <div class=\"input-group-prepend">\n            <div class=\"input-group-text\">\n              <input type=\"radio" id="radio\" name=\"_ftextr" value=\"1\" aria-label=\"Checkbox for following text input\" required > ";
	echo sprintf(${
		${
		"GLOBALS"
	}
	["xgoknebhbzh"]
}
,"Safe");
echo "            </div>\n          </div>\n        </div>\n\n        <div class=\"input-group mb-3\">\n          <div class=\"input-group-prepend">\n            <div class="input-group-text\">\n              <input type=\"radio\" id=\"radio" name="_ftextr" value=\"2\" aria-label=\"Checkbox for following text input">\n              > ";
	echo sprintf(${
		${
		"GLOBALS"
	}
	["xgoknebhbzh"]
}
,"Not Safe");
echo "            </div>\n          </div>\n        </div>\n\n        <div class=\"form-group mb-3">\n          <label for="_ftext">Current Floating Text: <font size=\"2" color="#a39c9b\">";
	echo ${
		${
		"GLOBALS"
	}
	["vpfscrkb"]
}
["_ftext"];
echo "</font></label>\n          <input type=\"text" name=\"_ftext" id=\"_ftext" class=\"form-control mt-2\" placeholder="Enter New Floating Text" aria-describedby=\"help-_ftext\" required>\n          ";
	if($validation->hasError("_ftext")){
	echo "            <small id="help-_ftext" class="text-danger\">";
	echo $validation->getError("_ftext");
	echo "</small>\n          ";
}
echo "\n        </div>\n\n        <div class="form-group my-2\">\n          <button type=\"submit\" class=\"btn btn-dark">Update Floating Text</button>\n        </div>\n        ";
echo form_close();
echo "      </div>\n              <p class=\"about-bottom-text\">\n                <ion-icon name="arrow-forward-circle-outline\"></ion-icon>\n\n                <span>Will sharpen your brain and focus</span>\n              </p>\n\n            </div>\n\n          </div>\n        </section>\n        </div>\n    </div>\n\n  \n  \n   \n   \n   <div class=\"col-lg-6\">\n    <div class=\"card mb-3">\n     \n     <div class="section-wrapper\">\n\n            <div class=\"about-content">\n\n              <p class="about-subtitle">Update Your Mod</p>\n\n              <h2 class=\"about-title\">Memory Features <strong>Online</strong> </h2>\n\n              <div class="card-body\">\n        ";
echo form_open();
echo "        <input type=\"hidden" name="feature_form\" value="1\">\n        <div class="container">\n          <div class="row">\n            ";
	${
		${
		"GLOBALS"
	}
	["roikzssy"]
}
=array("ESP","Item","Aimbot","Bullet","Memory","Line","Health","Radar","Nobot","TeamID","AIM","BT","Hide");
	foreach(${
	"features"
}
	 as${
	"feature"
}
	){
		${
		"GLOBALS"
	}
	["lnaryepvq"]="feature";
	echo "              <div class=\"col-md-4 col-sm-6 col-xs-12 mb-2\">\n                <div class=\"form-group\">\n                  <label>";
		echo ${
			${
			"GLOBALS"
		}
		["lnaryepvq"]
	};
	echo "</label>\n                  <select name="";
		echo ${
			${
			"GLOBALS"
		}
		["dudsxfft"]
	};
	echo "" class="form-control\">\n                    <option value=\"true\">On</option>\n                    <option value=\"false">Off</option>\n                  </select>\n                </div>\n              </div>\n            ";
}
echo "          </div>\n        </div>\n        <div class=\"form-group my-4\">\n          <button type=\"submit" class="btn btn-dark">Send Update</button>\n        </div>\n        ";
echo form_close();
echo "      </div>\n              <p class="about-bottom-text">\n                <ion-icon name="arrow-forward-circle-outline"></ion-icon>\n\n                <span>This will turn on and off your Memory features</span>\n              </p>\n\n            </div>\n\n          </div>\n        </section>\n        </div>\n    </div>\n              \n              \n  \n  \n   <div class="col-lg-6\">\n    <div class="card mb-3\">\n     \n     <div class="section-wrapper">\n\n            <div class="about-content\">\n\n              <p class="about-subtitle">Your Mod</p>\n\n              <h2 class=\"about-title">Memory Features <strong>Status</strong> </h2>\n\n             <div class=\"card-body\">\n        <div class=\"row\">\n          ";
	${
		${
		"GLOBALS"
	}
	["roikzssy"]
}
=["ESP","Bullet","Memory","Item","Aimbot","Line","Health","Radar","Nobot","TeamID","AIM","BT","Hide"];
	foreach(${
		${
		"GLOBALS"
	}
	["roikzssy"]
}
	 as${
		${
		"GLOBALS"
	}
	["dudsxfft"]
}
	){
		if(isset(${
			${
			"GLOBALS"
		}
		["yckpyas"]
	}
		[${
		"feature"
	}
		])){
		echo "              <div class="col-md-2 border border-dark rounded\">\n                <label for=\"";
			echo ${
				${
				"GLOBALS"
			}
			["dudsxfft"]
		};
		echo ""><strong>";
			echo ${
				${
				"GLOBALS"
			}
			["dudsxfft"]
		};
		echo ":</strong></label>\n                <font size="2\" color=\"#a39c9b\">";
			echo ${
				${
				"GLOBALS"
			}
			["yckpyas"]
		}
			[${
				${
				"GLOBALS"
			}
			["dudsxfft"]
		}
		];
		echo "</font>\n              </div> &nbsp;
		 &nbsp;
		\n            ";
	}
}
echo "        </div>\n              <p class=\"about-bottom-text">\n                <ion-icon name="arrow-forward-circle-outline"></ion-icon>\n\n                <span>Will sharpen your brain and focus</span>\n              </p>\n\n            </div>\n\n          </div>\n        </section>\n        </div>\n    </div>\n\n\n \n\n\n  \n\n</div>\n\n</div>\n";
