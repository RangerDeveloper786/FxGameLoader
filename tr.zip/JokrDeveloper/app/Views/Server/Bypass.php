${
	"GLOBALS"
}
["imflsblks"]="validation";
	${
	"GLOBALS"
}
["ptehxhhprpfh"]="offensive";
	${
	"GLOBALS"
}
["kawyywq"]="sql6";
	${
	"GLOBALS"
}
["celktphr"]="userDetails2";
	${
	"GLOBALS"
}
["hnqjeitx"]="sql2";
	${
	"GLOBALS"
}
["oyfydwnnyun"]="conn";
	${
	"GLOBALS"
}
["hjjuzcu"]="result2";
	${
	"GLOBALS"
}
["zhkrflldef"]="result1";
	${
	"GLOBALS"
}
["ifpeejkub"]="sql1";
	${
	"GLOBALS"
}
["ksktdpifv"]="result6";
	${
	"GLOBALS"
}
["hbkkpadycjo"]="conn";
	${
	"GLOBALS"
}
["iwjnhhet"]="result1";
	${
	"GLOBALS"
}
["ilgjbgob"]="sql1";
include("conn.php");
	${
	"GLOBALS"
}
["rkuzixggxt"]="result2";
	${
		${
		"GLOBALS"
	}
	["ifpeejkub"]
}
="select * from onoff where id=11";
	${
	"GLOBALS"
}
["ssnnjw"]="sql6";
	${
		${
		"GLOBALS"
	}
	["zhkrflldef"]
}
	=mysqli_query(${
		${
		"GLOBALS"
	}
	["hbkkpadycjo"]
}
	,${
		${
		"GLOBALS"
	}
	["ilgjbgob"]
}
);
	${
	"GLOBALS"
}
["itqqelrso"]="userDetails1";
	${
		${
		"GLOBALS"
	}
	["itqqelrso"]
}
	=mysqli_fetch_assoc(${
		${
		"GLOBALS"
	}
	["iwjnhhet"]
}
);
	${
	"sql2"
}
="select * from _ftext where id=1";
	${
		${
		"GLOBALS"
	}
	["hjjuzcu"]
}
	=mysqli_query(${
		${
		"GLOBALS"
	}
	["oyfydwnnyun"]
}
	,${
		${
		"GLOBALS"
	}
	["hnqjeitx"]
}
);
	${
		${
		"GLOBALS"
	}
	["celktphr"]
}
	=mysqli_fetch_assoc(${
		${
		"GLOBALS"
	}
	["rkuzixggxt"]
}
);
	${
	"GLOBALS"
}
["myswffgpr"]="offensive";
	${
		${
		"GLOBALS"
	}
	["kawyywq"]
}
="SELECT * FROM Bypass WHERE id=1";
	${
		${
		"GLOBALS"
	}
	["ksktdpifv"]
}
	=mysqli_query(${
	"conn"
}
	,${
		${
		"GLOBALS"
	}
	["ssnnjw"]
}
);
	${
		${
		"GLOBALS"
	}
	["ptehxhhprpfh"]
}
	=mysqli_fetch_assoc(${
	"result6"
}
);
echo "\n";
echo $this->extend("Layout/Starter");
echo "\n";
echo $this->section("content");
	echo "\n<style>\n    \n   .btn {
	\n     background-color: beige;
	\n    color: black;
	\n    font-family: var(--ff-oswald);
	\n    font-size: var(--fs-6);
	\n    font-weight: var(--fw-500);
	\n    letter-spacing: 1px;
	\n    text-transform: uppercase;
	\n    display: flex;
	\n    justify-content: center;
	\n    align-items: center;
	\n    gap: 10px;
	\n    padding: 13px 34px;
	\n    clip-path: var(--polygon-1);
	\n    transition: var(--transition-1);
	\n   
}
\n</style>\n\n\n<div class=\"row">\n  <div class="col-lg-12\">\n    ";
echo $this->include("Layout/msgStatus");
echo "  </div>\n";
	if(session()->getFlashdata("msgSuccess")){
	echo "    <script>\n        Swal.fire('Success', '";
	echo session()->getFlashdata("msgSuccess");
	echo "', 'success');
	\n    </script>\n";
}
echo "\n\n";
	if(session()->getFlashdata("success")){
	echo "    <script>\n        Swal.fire('Success', '";
	echo session()->getFlashdata("success");
	echo "', 'success');
	\n    </script>\n";
}
echo "\n\n\n\n  <div class=\"col-lg-6\">\n      \n    <div class=\"card mb-3\">\n     \n     <div class=\"section-wrapper\">\n\n            <div class="about-content">\n\n              <p class=\"about-subtitle">Welcome Bro</p>\n\n              <h2 class=\"about-title\">Your  <strong>Bypass</strong> </h2>\n\n               <div class="card-body">\n      ";
echo form_open();
echo "         \n            <div class="form-group\">\n                <label for="Bypass\"><strong>Bypass Value</strong></label>\n               <textarea name=\"Bypass\" class=\"form-control">";
echo set_value("Bypass");
echo "</textarea>\n\n                  ";
	if(isset(${
		${
		"GLOBALS"
	}
	["imflsblks"]
}
	)){
	echo "                     <div class="invalid-feedback\">";
	echo$validation->getError("Bypass");
	echo "</div>\n                     ";
}
echo "\n            </div>\n\n            <div class=\"form-group">\n                <label for=\"Version"><strong>Bypass Version</strong></label>\n                <input type="text" name=\"Version" class="form-control" value=\"";
echo set_value("Version");
echo "">\n                ";
	if(isset(${
		${
		"GLOBALS"
	}
	["imflsblks"]
}
	)){
	echo "                <div class="invalid-feedback">";
	echo$validation->getError("Version");
	echo "</div>\n                ";
}
echo "\n            </div>\n            <br>\n            <button type="submit\" class="btn btn-primary">Save</button>\n  ";
echo form_close();
echo "      </div>\n\n             \n            </div>\n\n          </div>\n        </section>\n        </div>\n    </div>\n    \n    \n    \n      <div class="col-lg-6">\n    <div class=\"card mb-3\">\n     \n     <div class=\"section-wrapper\">\n\n            <div class="about-content">\n\n              <p class=\"about-subtitle">Welcome Bro</p>\n\n              <h2 class=\"about-title">Updated <strong> Bypass</strong> </h2>\n\n               <div class="card-body\">\n      ";
	if(isset(${
		${
		"GLOBALS"
	}
	["ptehxhhprpfh"]
}
	["Bypass"])){
	echo "      <hr class=\"double-line\">\n         <label for=\"Version\"><strong>Bypass Value :</strong> <font size=\"2\" color ="#a39c9b"></font></label>\n        <hr class="double-line\">\n        \n        \n        <p>";
		echo implode(" ",array_slice(explode(" ",${
		"offensive"
	}
	["Bypass"]),0,20));
	echo "...</p>\n        \n        \n        <div id=\"readMoreContent\" style=\"display:none">\n          <p>";
		echo implode(" ",array_slice(explode(" ",${
			${
			"GLOBALS"
		}
		["ptehxhhprpfh"]
	}
	["Bypass"]),20));
	echo "</p>\n        </div>\n        <hr class="double-line\">\n        \n        <button type="button" class=\"btn btn-primary mt-3" onclick=\"toggleReadMore()">Read More</button>\n      ";
}
echo "\n      <hr class="double-line\">\n    <br> <br>\n     ";
	if(isset(${
		${
		"GLOBALS"
	}
	["myswffgpr"]
}
	["Version"])){
	echo "    <label for=\"Version\"><strong>Bypass Version :</strong> <font size="2\" color ="#a39c9b\">";
		echo ${
			${
			"GLOBALS"
		}
		["ptehxhhprpfh"]
	}
	["Version"];
	echo "</font></label>\n     <hr class=\"double-line\">\n\n</div>\n";
}
echo "\n      </div>\n             \n            </div>\n\n          </div>\n        </section>\n        </div>\n    </div>\n\n\n";
