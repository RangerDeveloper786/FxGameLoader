${
	"GLOBALS"
}
["qjmxuazqlns"]="blockKeySuccess";
	${
	"GLOBALS"
}
["ngoxjqtsfzd"]="resetSuccess";
	${
	"GLOBALS"
}
["nxipkkrr"]="key";
echo $this->extend("Layout/Starter");
echo "\n";
echo $this->section("content");
echo "\n    <div class="row\">\n  <div class=\"col-lg-12">\n    ";
echo $this->include("Layout/msgStatus");
echo "  </div>\n\n  <div class="col-lg-6\">\n    <div class="card mb-3">\n     \n     <div class="section-wrapper\">\n\n            <div class=\"about-content\">\n\n              <p class="about-subtitle">Welcome</p>\n\n              <h2 class="about-title\">Reset   <strong>Key</strong> </h2>\n\n                <div class="card-body">\n               <form action="";
echo base_url("ResetKey");
echo "" method=\"get">\n            <div>\n               <label for=\"userkey">User Key:</label>\n               <input type="text\" name=\"userkey" id="userkey" class=\"form-control\" required>\n            </div>\n            <div>\n               <label for=\"extend_time\">Extend Time:</label>\n               <input type="text" name="extend_time" id=\"extend_time" class="form-control" required>\n            </div>\n            <div class=\"mt-4 mb-0">\n               <div class="d-grid\"><button type=\"submit" class=\"btn btn-dark btn-block">Reset Key Time</button></div>\n            </div>\n         </form>\n            </div>\n\n              <p class=\"about-bottom-text\">\n                <ion-icon name="arrow-forward-circle-outline"></ion-icon>\n\n                <span>This will reset the key</span>\n              </p>\n\n            </div>\n\n          </div>\n        </section>\n        </div>\n    </div>\n    \n    \n    <div class=\"col-lg-6">\n    <div class=\"card mb-3\">\n     \n     <div class=\"section-wrapper">\n\n            <div class="about-content\">\n\n              <p class="about-subtitle\">Welcome</p>\n\n              <h2 class="about-title\">Reset   <strong>Key</strong> </h2>\n\n               <div class=\"card-body\">\n   <form action="";
echo base_url("resetKeyOne");
echo "\" method=\"get\">\n      <div>\n         <label for="userkey\">User Key:</label>\n         <input type="text\" name=\"userkey\" id=\"userkey\" class=\"form-control" value=\"";
	${
	"GLOBALS"
}
["hlzwpn"]="successMessage";
	echo ${
		${
		"GLOBALS"
	}
	["nxipkkrr"]
};
	${
	"GLOBALS"
}
["cqtdevot"]="successMessage";
echo "" required>\n      </div>\n      <div class=\"mt-4 mb-0">\n         <div class=\"d-grid\">\n            <button type=\"submit\" class=\"btn btn-dark btn-block">Reset Key</button>\n         </div>\n      </div>\n   </form>\n</div>\n            \n            \n           \n      \n\n              <p class="about-bottom-text\">\n                <ion-icon name=\"arrow-forward-circle-outline"></ion-icon>\n\n                <span>This will reset the key</span>\n              </p>\n\n            </div>\n\n          </div>\n        </section>\n        </div>\n    </div>\n    \n    \n    \n      <div class="col-lg-6">\n    <div class="card mb-3">\n     \n     <div class=\"section-wrapper">\n\n            <div class=\"about-content">\n\n              <p class="about-subtitle\">Welcome</p>\n\n              <h2 class="about-title">Key   <strong>Active & Deactive</strong> </h2>\n\n                <div class=\"card-body">\n              <form method=\"post" action="";
echo base_url("blockKey");
echo "\">\n    ";
echo csrf_field();
echo "    <div>\n        <label for="userkey\">Key:</label>\n        <input type="text\" name=\"userkey\" id=\"userkey\"   class="form-control" required>\n    </div>\n    <div><br>\n        <label for=\"action\">Action:</label>\n<div class=\"select-wrapper\" style=\"width: 200px;
">\n  <select name=\"action" id="action" required>\n    <option value="">-- Select Action --</option>\n    <option value="block">Block</option>\n    <option value=\"enable">Enable</option>\n  </select>\n  <i class=\"fas fa-angle-down\"></i> \n</div>\n    </div><br>\n    <div class="d-grid\"><button type=\"submit" class=\"btn btn-dark btn-block\">Update Key Status</button></div>\n</form>\n            </div>\n              <p class=\"about-bottom-text">\n                <ion-icon name=\"arrow-forward-circle-outline"></ion-icon>\n\n                <span>This will update key status</span>\n              </p>\n\n            </div>\n\n          </div>\n        </section>\n        </div>\n    </div>\n\n    \n    \n    \n    \n     <div class="col-lg-6">\n    <div class=\"card mb-3\">\n     \n     <div class="section-wrapper\">\n\n            <div class=\"about-content\">\n\n              <p class="about-subtitle\">Welcome</p>\n\n              <h2 class="about-title\">Key   <strong>Active & Deactive</strong> </h2>\n\n               <div class="card-body\" style=\"padding-bottom:130px;
\">\n        \n               <div class=\"d-grid">\n <a href=\"";
echo site_url("keys/download/new");
echo "" class=\"btn btn-outline-dark btn-lg\"><i class=\"bi bi-bookmark-plus"></i> Download New</a>\n</div>\n<br>\n<div class="d-grid\">\n <a href="";
echo site_url("keys/download/all");
echo "\" class="btn btn-outline-dark btn-lg"><i class=\"bi bi-bookmark-plus\"></i> Download All</a>\n</div>\n           \n    </div>\n              <p class="about-bottom-text">\n                <ion-icon name=\"arrow-forward-circle-outline"></ion-icon>\n\n                <span>This will download the key</span>\n              </p>\n\n            </div>\n\n          </div>\n        </section>\n        </div>\n    </div>\n    \n</div>\n\n<<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.all.min.js\"></script>\n\n\n";
	if(isset(${
		${
		"GLOBALS"
	}
	["ngoxjqtsfzd"]
}
	)&&${
	"resetSuccess"
}
	===true){
		echo "<script>\n  Swal.fire({
		\n    icon: 'success',\n    title: 'Success!',\n    text: 'The key has been reset, and devices are set to null.',\n  
	}
	);
	\n</script>\n";
}
echo "\n\n\n";
	if(isset(${
	"extendSuccess"
}
	)&&${
	"extendSuccess"
}
	===true&&isset(${
		${
		"GLOBALS"
	}
	["hlzwpn"]
}
	)){
		${
		"GLOBALS"
	}
	["saerqewhy"]="successMessage";
		echo "<script>\n  Swal.fire({
		\n    icon: 'success',\n    title: 'Success!',\n    text: ";
			echo json_encode(${
				${
				"GLOBALS"
			}
			["saerqewhy"]
		}
		);
		echo ",\n  
	}
	);
	\n</script>\n";
}
echo "\n\n";
	if(isset(${
		${
		"GLOBALS"
	}
	["qjmxuazqlns"]
}
	)&&${
		${
		"GLOBALS"
	}
	["qjmxuazqlns"]
}
	===true&&isset(${
		${
		"GLOBALS"
	}
	["cqtdevot"]
}
	)){
		echo "<script>\n  Swal.fire({
		\n    icon: 'success',\n    title: 'Success!',\n    text: ";
			echo json_encode(${
			"successMessage"
		}
		);
		echo ",\n  
	}
	);
	\n</script>\n";
}
echo "\n";
