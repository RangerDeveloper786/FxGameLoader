
	${
	"GLOBALS"
}
["bljnhycuyr"]="time";
	${
	"GLOBALS"
}
["hfnpydtld"]="history";
echo $this->extend("Layout/Starter");
echo "\n";
	${
	"GLOBALS"
}
["odcmcibjv"]="time";
	${
	"GLOBALS"
}
["sfyyybgmsoz"]="h";
echo $this->section("content");
echo "\n\n\n\n<main>\n    <article>\n\n      \n\n      <section class="hero\" id=\"hero\">\n        <div class=\"container">\n\n          <p class=\"hero-subtitle\">The Season 2.7</p>\n\n          <h1 class=\"h1 hero-title\">BGMI</h1>\n\n          <div class="btn-group">\n\n            <button class=\"btn btn-primary">\n              <span>Lets Plat with Mod</span>\n\n              <ion-icon name="play-circle\"></ion-icon>\n            </button>\n\n            <button class="btn btn-link">Push the ranks</button>\n\n          </div>\n\n        </div>\n      </section>\n\n\n\n\n\n      <div class="section-wrapper">\n\n        \n\n        <section class=\"about\" id=\"about">\n          <div class="container">\n\n            <figure class=\"about-banner\">\n\n              <img src="./assets/images/about-img.png" alt="M shape" class=\"about-img">\n\n              <img src="./assets/images/character-1.png" alt="Game character\" class=\"character character-1">\n\n              <img src="./assets/images/character-2.png" alt="Game character" class=\"character character-2\">\n\n              <img src="./assets/images/character-3.png\" alt=\"Game character" class=\"character character-3\">\n\n            </figure>\n\n            <div class="about-content">\n\n              <p class="about-subtitle\">Welcome Bro</p>\n\n              <h2 class=\"about-title">  <strong>User Information</strong> </h2>\n\n              <div class="card-body">\n                <div class="table-responsive\">\n                    <table class="table table-sm table-bordered table-hover text-center\">\n                        <tbody>\n                            ";
	foreach(${
		${
		"GLOBALS"
	}
	["hfnpydtld"]
}
	 as${
		${
		"GLOBALS"
	}
	["sfyyybgmsoz"]
}
	){
		${
		"GLOBALS"
	}
	["xlhjbvz"]="in";
	echo "                                ";
		${
			${
			"GLOBALS"
		}
		["xlhjbvz"]
	}
	=explode("|",$h->info);
	echo "                                <tr>\n                                    <td><span class="align-middle badge text-dark">#3812";
		${
		"GLOBALS"
	}
	["mbetbzq"]="in";
	echo $h->id_history;
	echo "</span></td>\n                                    <td>";
		echo ${
			${
			"GLOBALS"
		}
		["mbetbzq"]
	}
	[0];
	echo "</td>\n                                    <td><span class=\"align-middle badge text-dark\">";
		echo ${
		"in"
	}
	[1];
	echo "**</span></td>\n                                    <td><span class=\"align-middle badge text-dark\">";
		echo ${
		"in"
	}
	[2];
		${
		"GLOBALS"
	}
	["lkcoyhqh"]="in";
	echo " Days</span></td>\n                                    <td><span class=\"align-middle badge text-primary">";
		echo ${
			${
			"GLOBALS"
		}
		["lkcoyhqh"]
	}
	[3];
	echo " Devices</span></td>\n                                    <td><i class="align-middle badge text-muted\">";
		echo ${
		"time"
	}
	::parse($h->created_at)->humanize();
	echo "</i></td>\n                                </tr>\n                            ";
}
echo "\n                        </tbody>\n                    </table>\n                </div>\n            </div>\n            \n              <div class=\"card-body">\n                <ul class="list-group list-hover mb-3\">\n                    <li class="list-group-item list-group-item-action d-flex justify-content-between align-items-center\">\n                        Roles\n                        <span class="badge text-dark\">\n                            ";
echo getLevel($user->level);
echo "                        </span>\n                    </li>\n                    <li class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">\n                        Saldo\n                        <span class="badge text-dark\">\n                            \$";
echo $user->saldo;
echo "                        </span>\n                    </li>\n                </ul>\n                <ul class=\"list-group\">\n                    <li class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">\n                        Login Time\n                        <span class=\"badge text-dark\">\n                            ";
	echo ${
		${
		"GLOBALS"
	}
	["bljnhycuyr"]
}
::parse(session()->time_since)->humanize();
	${
	"GLOBALS"
}
["krvnqmv"]="time";
echo "                        </span>\n                    </li>\n                    <li class=\"list-group-item list-group-item-action d-flex justify-content-between align-items-center\">\n                        Auto Logout\n                        <span class="badge text-dark">\n                            ";
	echo ${
		${
		"GLOBALS"
	}
	["odcmcibjv"]
}
	::now()->difference(${
		${
		"GLOBALS"
	}
	["krvnqmv"]
}
::parse(session()->time_login))->humanize();
echo "                        </span>\n                    </li>\n                </ul>\n            </div>\n\n              <p class=\"about-bottom-text\">\n                <ion-icon name=\"arrow-forward-circle-outline\"></ion-icon>\n\n                <span>Will sharpen your brain and focus</span>\n              </p>\n\n            </div>\n\n          </div>\n        </section>\n\n\n\n\n\n        \n\n        <section class=\"team\" id="team\">\n          <div class=\"container\">\n\n            <h2 class="h2 section-title\">Active Team Members</h2>\n\n            <ul class="team-list">\n\n              <li>\n                <a href="#" class="team-member">\n                  <figure>\n                    <img src="./assets/images/team-member-1.png\" alt=\"Team member image">\n                  </figure>\n\n                  <ion-icon name="link-outline\"></ion-icon>\n                </a>\n              </li>\n\n              <li>\n                <a href=\"#" class=\"team-member">\n                  <figure>\n                    <img src=\"./assets/images/team-member-2.png" alt="Team member image\">\n                  </figure>\n\n                  <ion-icon name=\"link-outline\"></ion-icon>\n                </a>\n              </li>\n\n              <li>\n                <a href="#" class="team-member\">\n                  <figure>\n                    <img src="./assets/images/team-member-3.png" alt=\"Team member image\">\n                  </figure>\n\n                  <ion-icon name=\"link-outline"></ion-icon>\n                </a>\n              </li>\n\n              <li>\n                <a href=\"#" class="team-member\">\n                  <figure>\n                    <img src="./assets/images/team-member-4.png\" alt="Team member image">\n                  </figure>\n\n                  <ion-icon name=\"link-outline\"></ion-icon>\n                </a>\n              </li>\n\n              <li>\n                <a href=\"#\" class="team-member\">\n                  <figure>\n                    <img src="./assets/images/team-member-6.png" alt="Team member image">\n                  </figure>\n\n                  <ion-icon name="link-outline\"></ion-icon>\n                </a>\n              </li>\n\n              <li>\n                <a href="#" class="team-member">\n                  <figure>\n                    <img src="./assets/images/team-member-7.png" alt=\"Team member image">\n                  </figure>\n\n                  <ion-icon name=\"link-outline"></ion-icon>\n                </a>\n              </li>\n\n              <li>\n                <a href="#" class="team-member">\n                  <figure>\n                    <img src=\"./assets/images/team-member-8.png\" alt=\"Team member image">\n                  </figure>\n\n                  <ion-icon name=\"link-outline\"></ion-icon>\n                </a>\n              </li>\n\n              <li>\n                <a href=\"#" class="team-member\">\n                  <figure>\n                    <img src=\"./assets/images/team-member-9.png" alt="Team member image\">\n                  </figure>\n\n                  <ion-icon name=\"link-outline"></ion-icon>\n                </a>\n              </li>\n\n              <li>\n                <a href=\"#" class="team-member\">\n                  <figure>\n                    <img src="./assets/images/team-member-10.png" alt=\"Team member image">\n                  </figure>\n\n                  <ion-icon name=\"link-outline"></ion-icon>\n                </a>\n              </li>\n\n              <li>\n                <a href=\"#\" class=\"team-member">\n                  <figure>\n                    <img src=\"./assets/images/team-member-11.png" alt=\"Team member image\">\n                  </figure>\n\n                  <ion-icon name=\"link-outline\"></ion-icon>\n                </a>\n              </li>\n\n              <li>\n                <a href="#" class="team-member">\n                  <figure>\n                    <img src="./assets/images/team-member-12.png\" alt="Team member image\">\n                  </figure>\n\n                  <ion-icon name=\"link-outline"></ion-icon>\n                </a>\n              </li>\n\n            </ul>\n\n            <button class=\"btn btn-primary\">view all members</button>\n\n          </div>\n        </section>\n\n\n\n\n\n        \n\n\n\n\n\n        \n\n        <section class=\"newsletter\">\n          <div class=\"container">\n\n            <div class=\"newsletter-card">\n\n              <div class=\"newsletter-content\">\n                <figure class="newsletter-img\">\n                  <img src="./assets/images/newsletter-img.png\" alt=\"Newsletter image">\n                </figure>\n\n                <h2 class="h2 newsletter-title">Subscribe to our newsletter</h2>\n              </div>\n\n              <form action="\" class=\"newsletter-form\">\n                <input type="email" name="email" required placeholder="Your Email Address" class=\"input-field">\n\n                <button type=\"submit" class=\"btn btn-secondary">Subscribe</button>\n              </form>\n\n            </div>\n\n          </div>\n        </section>\n\n      </div>\n\n    </article>\n  </main>\n\n\n\n\n\n";
